package com.enlawebdekaaf.app.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.enlawebdekaaf.app.ejb.EjbActividad;
import com.enlawebdekaaf.app.ejbinterface.IEjbActividad;
import com.enlawebdekaaf.app.entity.Tactividad;
import com.enlawebdekaaf.app.jb.JbActividad;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * Servlet implementation class ServletActividadGenerarReporte
 */
@WebServlet("/ServletActividadGenerarReporte")
public class ServletActividadGenerarReporte extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private IEjbActividad iEjbActividad;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletActividadGenerarReporte() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		iEjbActividad=new EjbActividad();
		
		iEjbActividad.getByIdUsuario(Integer.parseInt(request.getSession().getAttribute("idUsuario").toString()));
		
		List<JbActividad> listaJbActividad=new ArrayList<JbActividad>();
		
		for (Tactividad item : iEjbActividad.getListaActividad())
		{
			JbActividad jbActividad=new JbActividad();
			
			jbActividad.setIdActividad(item.getIdActividad());						
			jbActividad.setNombre(item.getNombre());
			jbActividad.setDescripcion(item.getDescripcion());
			jbActividad.setEstado(item.getEstado());
			jbActividad.setFechaHoraInicio(item.getFechaHoraInicio());
			jbActividad.setFechaHoraFin(item.getFechaHoraFin());
			jbActividad.setFechaRegistro(item.getFechaRegistro());
			jbActividad.setLugar(item.getLugar());
			
			listaJbActividad.add(jbActividad);
		}
		
		byte[] bytes;
		
		try
		{
			bytes = JasperRunManager.runReportToPdf(this.getServletContext().getRealPath("/WEB-INF/classes/com/enlawebdekaaf/app/report/ReporteActividades.jasper"), null, new JRBeanCollectionDataSource(listaJbActividad));

			response.setContentType("application/pdf");
			response.setContentLength(bytes.length);
			ServletOutputStream ouputStream = response.getOutputStream();
			ouputStream.write(bytes, 0, bytes.length);
			ouputStream.flush();
			ouputStream.close();
		}
		catch(JRException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
