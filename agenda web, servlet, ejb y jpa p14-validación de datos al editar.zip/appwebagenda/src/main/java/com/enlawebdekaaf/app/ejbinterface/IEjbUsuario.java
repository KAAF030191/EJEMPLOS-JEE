package com.enlawebdekaaf.app.ejbinterface;

import java.util.List;
import java.util.Map;

import javax.ejb.Local;

import com.enlawebdekaaf.app.entity.Tusuario;

@Local
public interface IEjbUsuario {
	public Map<String, String> insert();
	public void getByIdUsuario();
	public Map<String, String> update();
	
	public void setUsuario(Tusuario usuario);
	public Tusuario getUsuario();
	public void setListaUsuario(List<Tusuario> listaTusuario);
	public List<Tusuario> getListaUsuario();
	
	public void setCorreoElectronicoAnterior(String correoElectronicoAnterior);
	public String getCorreoElectronicoAnterior();
	public void setContraseniaAnterior(String contraseniaAnterior);
	public String getContraseniaAnterior();
	public void setContraseniaNueva(String contraseniaNueva);
	public String getContraseniaNueva();
	public void setContraseniaRepita(String contraseniaRepita);
	public String getContraseniaRepita();
}
