-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 23-12-2014 a las 18:59:35
-- Versión del servidor: 5.6.12-log
-- Versión de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `dbejemplojpa`
--
CREATE DATABASE IF NOT EXISTS `dbejemplojpa` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbejemplojpa`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tpersona`
--

CREATE TABLE IF NOT EXISTS `tpersona` (
  `idPersona` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(70) NOT NULL,
  `documentoIdentidad` char(8) NOT NULL,
  `correoElectronico` varchar(700) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `fechaRegistro` datetime NOT NULL,
  PRIMARY KEY (`idPersona`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tpersona`
--

INSERT INTO `tpersona` (`idPersona`, `nombre`, `documentoIdentidad`, `correoElectronico`, `fechaNacimiento`, `estado`, `fechaRegistro`) VALUES
(1, 'Kevin Arnold Arias Figuera', '77777777', 'KAAF030191@gmail.com', '1991-01-03', 1, '2014-12-23 13:33:09'),
(2, 'En la web de KAAF', '11111111', 'enlawebdekaaf@gmail.com', '2014-01-01', 1, '2014-12-23 13:34:40');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
