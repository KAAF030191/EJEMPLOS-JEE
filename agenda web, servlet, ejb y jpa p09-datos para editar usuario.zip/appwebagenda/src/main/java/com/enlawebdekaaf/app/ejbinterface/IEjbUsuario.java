package com.enlawebdekaaf.app.ejbinterface;

import java.util.List;
import java.util.Map;

import javax.ejb.Local;

import com.enlawebdekaaf.app.entity.Tusuario;

@Local
public interface IEjbUsuario {
	public Map<String, String> insert();
	public Tusuario getByIdUsuario();
	
	public void setUsuario(Tusuario usuario);
	public Tusuario getUsuario();
	public void setListaUsuario(List<Tusuario> listaTusuario);
	public List<Tusuario> getListaUsuario();
	
	public void setContraseniaRepita(String contraseniaRepita);
	public String getContraseniaRepita();
}
