package com.enlawebdekaaf.app.appwebconexionpool;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

public class Conexion {
	private DataSource dataSource=null;
	private BasicDataSource basicDataSource=null;
	private Connection connection=null;

	public Conexion()
	{
		try
		{
			basicDataSource=new BasicDataSource();
			
			basicDataSource.setDriverClassName("com.mysql.jdbc.Driver");
			basicDataSource.setUsername("root");
			basicDataSource.setPassword("030191");
			basicDataSource.setUrl("jdbc:mysql://localhost:3306/dbappwebconexionpool");
			basicDataSource.setMaxActive(50);
			basicDataSource.setMaxIdle(50);
			basicDataSource.setRemoveAbandoned(true);
			basicDataSource.setRemoveAbandonedTimeout(5000);
			basicDataSource.setMaxWait(6000);
			
			dataSource=basicDataSource;
			
			connection=dataSource.getConnection();
		}
		catch(SQLException ex)
		{
			System.out.println("SqlException "+ex.getMessage());
		}
		catch(Exception ex)
		{
			System.out.println("Exception "+ex.getMessage());
		}
	}
	
	public void devolverConexionPool()
	{
		if(connection!=null)
		{
			try
			{
				connection.close();
				connection=null;
			}
			catch(Exception ex)
			{
				System.out.println("Error al cerrar la conexi�n "+ex.getMessage());
			}
		}
	}
	
	public Connection getConnection() {
		return connection;
	}
}
