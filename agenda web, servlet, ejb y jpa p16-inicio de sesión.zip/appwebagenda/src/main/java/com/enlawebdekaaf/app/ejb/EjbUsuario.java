package com.enlawebdekaaf.app.ejb;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.enlawebdekaaf.app.appwebagenda.MiHelper;
import com.enlawebdekaaf.app.dao.DaoUsuario;
import com.enlawebdekaaf.app.daointerface.IDaoUsuario;
import com.enlawebdekaaf.app.ejbinterface.IEjbUsuario;
import com.enlawebdekaaf.app.entity.Tusuario;

@Stateless
public class EjbUsuario implements IEjbUsuario {
	private EntityManagerFactory emf=null;
	private EntityManager em=null;
	private EntityTransaction et=null;
	
	private Tusuario usuario;
	private List<Tusuario> listaUsuario;
	
	private String correoElectronicoAnterior;
	private String contraseniaAnterior;
	private String contraseniaNueva;
	private String contraseniaRepita;

	public EjbUsuario()
	{
		usuario=new Tusuario();
	}
	
	@Override
	public Map<String, String> insert() {
		Map<String, String> returnMap=new HashMap<String, String>();
		String mensajeGeneral="";
		
		try
		{			
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			
			String fechaActual=sdf.format(new Date());
			
			usuario.setFechaRegistro(fechaActual);
			usuario.setFechaModificacion(fechaActual);
			
			if(!usuario.getContrasenia().equals(contraseniaRepita))
			{
				mensajeGeneral+="Las contrase�as no coneciden<br>";
			}
			
			ValidatorFactory validatorFactory=Validation.buildDefaultValidatorFactory();
			Validator validator=validatorFactory.getValidator();
			
			Set<ConstraintViolation<Tusuario>> constraint=validator.validate(usuario);
			
			for(ConstraintViolation<Tusuario> item : constraint)
			{
				mensajeGeneral+=item.getMessage()+"<br>";
			}
			
			usuario.setContrasenia(new MiHelper().encrypt(usuario.getContrasenia()));
			
			IDaoUsuario iDaoUsuario=new DaoUsuario();
			
			emf=Persistence.createEntityManagerFactory("appwebagenda");
			em=emf.createEntityManager();
			et=em.getTransaction();
			
			et.begin();
			
			if(iDaoUsuario.getByCorreoElectronico(em, usuario.getCorreoElectronico())!=null)
			{
				mensajeGeneral+="El correo electr�nico ya fue registrado con anterioridad<br>";
			}
			
			if(!mensajeGeneral.equals(""))
			{
				et.rollback();
				
				returnMap.put("correcto", "No");
				returnMap.put("mensajeGeneral", mensajeGeneral);
				
				return returnMap;
			}
			
			iDaoUsuario.insert(em, usuario);
			
			et.commit();
			
			returnMap.put("correcto", "Si");
			returnMap.put("mensajeGeneral", "Registro realizado correctamente<br>");
			
			return returnMap;
		}
		catch(Exception ex)
		{
			if(et!=null)
			{
				et.rollback();
			}
			
			System.out.println("Error: "+ex.getMessage());
			
			returnMap.put("correcto", "No");
			
			return returnMap;
		}
		finally
		{
			if(em!=null)
			{
				em.close();
				em=null;
			}
			if(emf!=null)
			{
				emf.close();
				emf=null;
			}
			
			et=null;
		}
	}
	
	public void getByIdUsuario()
	{
		try
		{
			IDaoUsuario iDaoUsuario=new DaoUsuario();
			
			emf=Persistence.createEntityManagerFactory("appwebagenda");
			em=emf.createEntityManager();
			et=em.getTransaction();
			
			et.begin();
			
			usuario=iDaoUsuario.getByIdUsuario(em, 1);
			
			et.commit();
		}
		catch(Exception ex)
		{
			if(et!=null)
			{
				et.rollback();
			}
			
			System.out.println("Error: "+ex.getMessage());
		}
		finally
		{
			if(em!=null)
			{
				em.close();
				em=null;
			}
			if(emf!=null)
			{
				emf.close();
				emf=null;
			}
			
			et=null;
		}
	}
	
	public Map<String, String> update()
	{
		Map<String, String> returnMap=new HashMap<String, String>();
		String mensajeGeneral="";
		
		try
		{
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			
			String fechaActual=sdf.format(new Date());
			
			usuario.setFechaModificacion(fechaActual);
			
			if(!contraseniaAnterior.equals(""))
			{
				if(usuario.getContrasenia().equals(new MiHelper().encrypt(contraseniaAnterior)))
				{
					usuario.setContrasenia(new MiHelper().encrypt(contraseniaNueva));
				}
				else
				{
					mensajeGeneral+="La contrase�a anterior no es la correcta<br>";
				}
			}
			
			ValidatorFactory validatorFactory=Validation.buildDefaultValidatorFactory();
			Validator validator=validatorFactory.getValidator();
			
			Set<ConstraintViolation<Tusuario>> constraint=validator.validate(usuario);
			
			for(ConstraintViolation<Tusuario> item : constraint)
			{
				mensajeGeneral+=item.getMessage()+"<br>";
			}
			
			if(mensajeGeneral!="")
			{
				returnMap.put("correcto", "No");
				returnMap.put("mensajeGeneral", mensajeGeneral);
				
				return returnMap;
			}
			
			IDaoUsuario iDaoUsuario=new DaoUsuario();
			
			emf=Persistence.createEntityManagerFactory("appwebagenda");
			em=emf.createEntityManager();
			et=em.getTransaction();
			
			et.begin();
			
			if(iDaoUsuario.getByCorreoElectronico(em, usuario.getCorreoElectronico())!=null)
			{
				if(!iDaoUsuario.getByCorreoElectronico(em, usuario.getCorreoElectronico()).getCorreoElectronico().equals(correoElectronicoAnterior))
				{
					mensajeGeneral+="El correo electr�nico ya fue registrado con anterioridad<br>";
				}
			}
			
			if(!mensajeGeneral.equals(""))
			{
				et.rollback();
				
				returnMap.put("correcto", "No");
				returnMap.put("mensajeGeneral", mensajeGeneral);
				
				return returnMap;
			}
			
			iDaoUsuario.update(em, usuario);
			
			et.commit();
			
			returnMap.put("correcto", "Si");
			returnMap.put("mensajeGeneral", "Datos guardados correctamente");
			
			return returnMap;
		}
		catch(Exception ex)
		{
			if(et!=null)
			{
				et.rollback();
			}
			
			System.out.println("Error: "+ex.getMessage());
			
			returnMap.put("correcto", "No");
			
			return returnMap;
		}
		finally
		{
			if(em!=null)
			{
				em.close();
				em=null;
			}
			if(emf!=null)
			{
				emf.close();
				emf=null;
			}
			
			et=null;
		}
	}
	
	public void getByCorreoElectronico(String correoElectronico)
	{
		try
		{
			IDaoUsuario iDaoUsuario=new DaoUsuario();
			
			emf=Persistence.createEntityManagerFactory("appwebagenda");
			em=emf.createEntityManager();
			et=em.getTransaction();
			
			et.begin();
			
			usuario=iDaoUsuario.getByCorreoElectronico(em, correoElectronico);
			
			et.commit();
		}
		catch(Exception ex)
		{
			if(et!=null)
			{
				et.rollback();
			}
			
			System.out.println("Error: "+ex.getMessage());
		}
		finally
		{
			if(em!=null)
			{
				em.close();
				em=null;
			}
			if(emf!=null)
			{
				emf.close();
				emf=null;
			}
			
			et=null;
		}
	}
	
	public Map<String, String> login(String contrasenia)
	{
		Map<String, String> returnMap=new HashMap<String, String>();
		String mensajeGeneral="";
		
		try
		{
			if(usuario==null)
			{
				mensajeGeneral+="Usuario o contrase�a incorrecto N1<br>";
			}
			else
			{
				if((new MiHelper()).encrypt(contrasenia).equals(usuario.getContrasenia()))
				{
					returnMap.put("correcto", "Si");
					returnMap.put("mensajeGeneral", "Inicio de sesi�n correcto");
					
					return returnMap;
				}
				else
				{
					mensajeGeneral+="Usuario o contrase�a incorrecto N2<br>";
				}
			}
			
			if(mensajeGeneral!="")
			{
				returnMap.put("correcto", "No");
				returnMap.put("mensajeGeneral", mensajeGeneral);
				
				return returnMap;
			}
			
			return null;
		}
		catch(Exception ex)
		{
			if(et!=null)
			{
				et.rollback();
			}
			
			System.out.println("Error: "+ex.getMessage());
			
			returnMap.put("correcto", "No");
			
			return returnMap;
		}
		finally
		{
			if(em!=null)
			{
				em.close();
				em=null;
			}
			if(emf!=null)
			{
				emf.close();
				emf=null;
			}
			
			et=null;
		}
	}
	
	@Override
	public Tusuario getUsuario() {
		return usuario;
	}
	@Override
	public void setUsuario(Tusuario usuario) {
		this.usuario = usuario;
	}
	@Override
	public List<Tusuario> getListaUsuario() {
		return listaUsuario;
	}
	@Override
	public void setListaUsuario(List<Tusuario> listaUsuario) {
		this.listaUsuario = listaUsuario;
	}
	
	@Override
	public String getCorreoElectronicoAnterior() {
		return correoElectronicoAnterior;
	}

	@Override
	public void setCorreoElectronicoAnterior(String correoElectronicoAnterior) {
		this.correoElectronicoAnterior = correoElectronicoAnterior;
	}
	
	@Override
	public String getContraseniaAnterior() {
		return contraseniaAnterior;
	}

	@Override
	public void setContraseniaAnterior(String contraseniaAnterior) {
		this.contraseniaAnterior = contraseniaAnterior;
	}
	@Override
	public String getContraseniaNueva() {
		return contraseniaNueva;
	}

	@Override
	public void setContraseniaNueva(String contraseniaNueva) {
		this.contraseniaNueva = contraseniaNueva;
	}
	@Override
	public String getContraseniaRepita() {
		return contraseniaRepita;
	}
	@Override
	public void setContraseniaRepita(String contraseniaRepita) {
		this.contraseniaRepita = contraseniaRepita;
	}
	
}
