package com.enlawebdekaaf.app.entity;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import java.util.List;


/**
 * The persistent class for the tusuario database table.
 * 
 */
@Entity
@NamedQuery(name="Tusuario.getByCorreoElectronico", query="SELECT t FROM Tusuario t where t.correoElectronico=:correoElectronico")
public class Tusuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idUsuario;

	@NotNull(message="El campo \"Apellido\" es requerido")
	@Size(min=1, max=40, message="El campo \"Apellido\" debe tener la longitud entre 1-40")
	private String apellido;

	@NotNull(message="El campo \"Contrase�a\" es requerido")
	@Size(min=4, max=700, message="El campo \"Contrase�a\" debe tener la longitud entre 4-700")
	private String contrasenia;

	@NotNull(message="El campo \"Correo electr�nico\" es requerido")
	@Size(min=6, max=700, message="El campo \"Correo electr�nico\" debe tener la longitud entre 6-700")
	@Pattern(regexp="[a-zA-Z0-9\\.\\-\\_]+\\@[a-zA-Z0-9\\-\\_]+\\.[a-zA-Z]{2,4}", message="El campo \"Correo electr�nico\" no cumple el formato adecuado. Ejm: ejemplo@gmail.com")
	private String correoElectronico;

	@NotNull(message="\"La Fecha de modificaci�n\" es requerido")
	@Pattern(regexp="(\\d{4}\\/\\d{2}\\/\\d{2}\\s\\d{2}\\:\\d{2}\\:\\d{2})|(\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}\\:\\d{2}\\:\\d{2}\\.[0-9]{1,3})", message="El formato de la fecha de registro no es el correcto. Ejm: yyyy/mm/dd hh:mm:ss")
	private String fechaModificacion;

	@NotNull(message="El campo \"Fecha de nacimiento es requerido\" es requerido")
	@Pattern(regexp="\\d{4}\\-\\d{2}\\-\\d{2}", message="El campo \"Fecha de nacimiento\" no cumple el formato adecuado. Ejm: dd/mm/yyyy")
	private String fechaNacimiento;

	@NotNull(message="\"La fecha de registro\" es requerido")
	@Pattern(regexp="(\\d{4}\\/\\d{2}\\/\\d{2}\\s\\d{2}\\:\\d{2}\\:\\d{2})|(\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}\\:\\d{2}\\:\\d{2}\\.[0-9]{1,3})", message="El formato de la fecha de registro no es el correcto. Ejm: yyyy/mm/dd hh:mm:ss")
	private String fechaRegistro;

	@NotNull(message="El campo \"Nombre\" es requerido")
	@Size(min=1, max=70, message="El campo \"Nombre\" debe tener la longitud entre 1-70")
	private String nombre;

	//bi-directional many-to-one association to Tactividad
	@OneToMany(mappedBy="tusuario")
	private List<Tactividad> tactividads;

	public Tusuario() {
	}

	public int getIdUsuario() {
		return this.idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getApellido() {
		return this.apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getContrasenia() {
		return this.contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}

	public String getCorreoElectronico() {
		return this.correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public String getFechaModificacion() {
		return this.fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getFechaNacimiento() {
		return this.fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getFechaRegistro() {
		return this.fechaRegistro;
	}

	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Tactividad> getTactividads() {
		return this.tactividads;
	}

	public void setTactividads(List<Tactividad> tactividads) {
		this.tactividads = tactividads;
	}

	public Tactividad addTactividad(Tactividad tactividad) {
		getTactividads().add(tactividad);
		tactividad.setTusuario(this);

		return tactividad;
	}

	public Tactividad removeTactividad(Tactividad tactividad) {
		getTactividads().remove(tactividad);
		tactividad.setTusuario(null);

		return tactividad;
	}

}