create database dbappwebcrud;
use dbappwebcrud;

create table tpersona
(
id int auto_increment,
nombre varchar(70) not null,
apellido varchar(40) not null,
documentoIdentidad char(8) not null,
correoElectronico varchar(700) not null,
fechaNacimiento date not null,
fechaRegistro datetime not null,
fechaActualizacion datetime not null,
primary key(id)
);