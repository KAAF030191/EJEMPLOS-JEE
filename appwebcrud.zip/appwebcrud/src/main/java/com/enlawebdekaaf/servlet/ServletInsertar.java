package com.enlawebdekaaf.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.enlawebdekaaf.app.appwebcrud.Conexion;
import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class ServletInsertar
 */
public class ServletInsertar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletInsertar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("insertar.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Conexion conexion=new Conexion();
		
		try
		{
			String fechaRegistro;
			String fechaActualizacion;
			
			SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			
			fechaRegistro=dateFormat.format(new Date());
			fechaActualizacion=fechaRegistro;
			
			String sql="insert into tpersona(nombre, apellido, documentoIdentidad, correoElectronico, fechaNacimiento, fechaRegistro, fechaActualizacion) values(?, ?, ?, ?, ?, ?, ?)";
			
			PreparedStatement prepareStatemente=(PreparedStatement)conexion.getConexion().prepareStatement(sql);
			
			prepareStatemente.setString(1, request.getParameter("txtNombre"));
			prepareStatemente.setString(2, request.getParameter("txtApellido"));
			prepareStatemente.setString(3, request.getParameter("txtDocumentoIdentidad"));
			prepareStatemente.setString(4, request.getParameter("txtCorreoElectronico"));
			prepareStatemente.setString(5, request.getParameter("dateFechaNacimiento"));
			prepareStatemente.setString(6, fechaRegistro);
			prepareStatemente.setString(7, fechaActualizacion);
			
			prepareStatemente.execute();
			
			prepareStatemente.close();
			
			request.setAttribute("mensaje", "Registro realizado correctamente");
			
			request.getRequestDispatcher("insertar.jsp").forward(request, response);
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		finally
		{
			conexion.cerrarConexion();
		}
	}

}
