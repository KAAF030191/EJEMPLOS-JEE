package com.enlawebdekaaf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.enlawebdekaaf.app.appwebcrud.Conexion;
import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class ServletEliminar
 */
public class ServletEliminar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletEliminar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
Conexion conexion=new Conexion();
		
		try
		{			
			String sql="delete from tpersona where id=?";
			
			PreparedStatement prepareStatemente=(PreparedStatement)conexion.getConexion().prepareStatement(sql);
			
			prepareStatemente.setString(1, request.getParameter("id"));
			
			prepareStatemente.execute();
			
			prepareStatemente.close();
			
			request.getRequestDispatcher("eliminar.jsp").forward(request, response);
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		finally
		{
			conexion.cerrarConexion();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
