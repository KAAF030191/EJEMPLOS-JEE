package com.enlawebdekaaf.app.ejb;

import javax.ejb.Local;

import com.enlawebdekaaf.app.ejbinterface.IEjbEjemplo;

@Local
public interface EjbEjemploLocal extends IEjbEjemplo{

}
