package com.enlawebdekaaf.app.ejb;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class EjbEjemplo
 */
@Stateless
public class EjbEjemplo implements EjbEjemploRemote, EjbEjemploLocal {

    /**
     * Default constructor. 
     */
    public EjbEjemplo() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String saludo(String nombre) {
		return "Hola "+nombre+" desde el ejb remoto";
	}

}
