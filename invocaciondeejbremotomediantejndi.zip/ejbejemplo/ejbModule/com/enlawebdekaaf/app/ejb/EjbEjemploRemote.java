package com.enlawebdekaaf.app.ejb;

import javax.ejb.Remote;

import com.enlawebdekaaf.app.ejbinterface.IEjbEjemplo;

@Remote
public interface EjbEjemploRemote extends IEjbEjemplo{

}
