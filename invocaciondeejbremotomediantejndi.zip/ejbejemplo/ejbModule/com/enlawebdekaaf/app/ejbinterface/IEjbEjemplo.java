package com.enlawebdekaaf.app.ejbinterface;

public interface IEjbEjemplo 
{
	public String saludo(String nombre);
}
