import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.JOptionPane;

import com.enlawebdekaaf.app.ejb.EjbEjemploRemote;


public class Main {
	public static void main(String[] args) {
		try
		{
			Properties jndiProperties=new Properties();
			
			jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
			jndiProperties.put(Context.PROVIDER_URL, "http-remoting://127.0.0.1:8080");
			jndiProperties.put(Context.SECURITY_PRINCIPAL, "KAAF030191");
			jndiProperties.put(Context.SECURITY_CREDENTIALS, "030191kaaf7!!!");
			jndiProperties.put("jboss.naming.client.ejb.context", true);
			
			Context context=new InitialContext(jndiProperties);
			
			EjbEjemploRemote ejbEjemploRemote=(EjbEjemploRemote)context.lookup("ejbejemplo/EjbEjemplo!com.enlawebdekaaf.app.ejb.EjbEjemploRemote");
			
			JOptionPane.showMessageDialog(null, ejbEjemploRemote.saludo("Kevin Arnold"));
		}
		catch(NamingException ex)
		{
			System.out.println("Error: "+ex.getMessage());
		}
		catch(Exception ex)
		{
			System.out.println("Error: "+ex.getMessage());
		}
	}

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public Main() {
		super();
	}

}