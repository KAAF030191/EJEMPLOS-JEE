package com.enlawebdekaaf.app.ejb;

import javax.ejb.Local;

@Local
public interface EjbPruebaLocal 
{
	public String saludo(String nombre);
}
