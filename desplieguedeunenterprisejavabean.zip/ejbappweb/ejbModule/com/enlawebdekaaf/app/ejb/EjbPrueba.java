package com.enlawebdekaaf.app.ejb;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class EjbPrueba
 */
@Stateless
public class EjbPrueba implements EjbPruebaLocal {

    /**
     * Default constructor. 
     */
    public EjbPrueba() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String saludo(String nombre) {
		return "Hola "+nombre+" desde el EJB en la web enlawebdekaaf.blogspot.com";
	}

}
