package com.enlawebdekaaf.app.dao;

import javax.persistence.EntityManager;

import com.enlawebdekaaf.app.daointerface.IDaoActividad;
import com.enlawebdekaaf.app.entity.Tactividad;

public class DaoActividad implements IDaoActividad{

	@Override
	public boolean insert(EntityManager em, Tactividad actividad) throws Exception {
		em.persist(actividad);
		
		return true;
	}

}
