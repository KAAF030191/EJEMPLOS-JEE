package com.enlawebdekaaf.app.daointerface;

import javax.persistence.EntityManager;

import com.enlawebdekaaf.app.entity.Tactividad;

public interface IDaoActividad {
	public boolean insert(EntityManager em, Tactividad actividad) throws Exception;
}
