package com.enlawebdekaaf.app.daointerface;

import java.util.List;

import javax.persistence.EntityManager;

import com.enlawebdekaaf.app.entity.Tactividad;

public interface IDaoActividad {
	public boolean insert(EntityManager em, Tactividad actividad) throws Exception;
	public List<Tactividad> getByIdUsuario(EntityManager em, int idUsuario) throws Exception;
	public List<Tactividad> getByIdUsuarioAndEstado(EntityManager em, int idUsuario, boolean estado) throws Exception;
}
